from django import forms

from .models import Task

class TaskForm(forms.ModelForm):
    class Meta:
        model = Task
        fields = ["title", "category"]
        labels = {"title": "Задача", "category": "Категория"}
