Список задач на Flask — код после шага 5 из 6 (PyWeb Guide)
https://pywebguide.github.io/project.html#flask

Так выглядит проект, если шаги 1–5 сделаны правильно. Сверьте с ним свои файлы
или распакуйте и продолжайте с шага 6.
Полный код проекта: https://pywebguide.github.io/examples/flask-todo.zip

Окружение и зависимости — как в шаге 1:
    python -m venv .venv
    .venv\Scripts\activate          (macOS и Linux: source .venv/bin/activate)
    pip install -r requirements.txt
Запуск: flask --app app run --debug
